const puppeteer = require("puppeteer");

(async () => {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  await page.goto("https://ctg.greythr.com/");
  await page.waitForTimeout(6000);
  await page.type("#username", "0292");
  await page.type("#password", "nandhu@3010");
  await page.waitForTimeout(6000);
  await page.click('button[type="submit"]');
  await page.waitForNavigation();

  await page.waitForTimeout(6000);
  await page.waitForSelector("gt-button", { visible: true });
  await page.click("gt-button");

  await page.waitForTimeout(5000);
  const dropdownVal = await page.evaluate(() => {
    const shadowRoot = document.querySelector('gt-dropdown').shadowRoot;
    const dropdownButton = shadowRoot.querySelector('.dropdown-button').textContent;
    console.log(dropdownButton, "dropdown");
    return dropdownButton;

  });
  if (dropdownVal === 'Select') {
    console.log("entered");
    await page.evaluate(() => {
      const shadowRoot = document.querySelector('gt-dropdown').shadowRoot;
      const dropdownButton = shadowRoot.querySelector('.dropdown-button');
      dropdownButton.click();
    });
    await page.waitForTimeout(5000);

    await page.evaluate(() => {
      const shadowRoot = document.querySelector('gt-dropdown').shadowRoot;
      const val = shadowRoot.querySelectorAll('.dropdown-container .dropdown-body div.dropdown-item')[1];
      val.click();
    });
    await page.waitForTimeout(3000);
    await page.evaluate(() => {
      const signIn = document.querySelector("gt-button.flex.justify-end.hydrated").shadowRoot;
      signIn.querySelector('button').click();
    });
  }

  else {
    // await page.waitForTimeout(5000);
    await page.evaluate(() => {
      const signOut = document.querySelector("gt-button.flex.justify-end.hydrated").shadowRoot;
      signOut.querySelector('button').click();
    });
  }
  await page.screenshot({ path: "root.png" });
  await browser.waitForTarget(() => false);
  await browser.close();
})();
